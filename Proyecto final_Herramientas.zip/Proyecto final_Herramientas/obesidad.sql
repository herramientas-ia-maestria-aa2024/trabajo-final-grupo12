use obesidad;
select * from obesidadsql LIMIT 10;